#define EEPROM	EEPROMClass::EEPROMInstance
#define INT64	(__int64)
