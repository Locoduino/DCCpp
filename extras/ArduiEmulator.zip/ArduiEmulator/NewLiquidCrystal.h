//-------------------------------------------------------------------
#ifndef __NewLiquidCrystalEmulator_H__
#define __NewLiquidCrystalEmulator_H__
//-------------------------------------------------------------------

#include "NewLiquidCrystal.hpp"
#endif