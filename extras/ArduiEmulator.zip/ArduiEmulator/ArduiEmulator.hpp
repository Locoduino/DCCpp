//-------------------------------------------------------------------
#pragma once
#ifndef __arduinoEmulator_H__
#define __arduinoEmulator_H__
//-------------------------------------------------------------------

#include "ArduiEmulator.inc"
#include "ArduinoForm.hpp"

namespace ArduiEmulator
{
	public ref class Arduino
	{
	public:
		static array<int>^ VC_pins;
		static array<String^>^ VC_pinNames;

		static long int _TCCR0A;
		static long int _TCCR0B;
		static long int _TCCR1A;
		static long int _TCCR1B;
		static long int _TCCR2A;
		static long int _TCCR2B;
		static long int _TCCR3A;
		static long int _TCCR3B;

		static long int _TIMSK0;
		static long int _TIMSK1;
		static long int _TIMSK2;
		static long int _TIMSK3;

		static long int _OCR0A;
		static long int _OCR0B;
		static long int _OCR1A;
		static long int _OCR1B;
		static long int _OCR2A;
		static long int _OCR2B;
		static long int _OCR3A;
		static long int _OCR3B;

		static long int _CLKPR;

		static unsigned char *__heap_start__;
		static unsigned char *__brkval__;

		static void _delay(int millis);
		static void _delayMicroseconds(int micros);

		static uint8_t _pgm_read_byte(const uint8_t *str);
		static int _pgm_read_word(const char *str);
		static void _pinSetup();
		static void _pinMode(int inPin, int inType);
		static void _digitalWrite(int inPin, int inValue);
		static int _digitalRead(int inPin);
		static void _analogWrite(int inPin, int inValue);
		static int _analogRead(int inPin);
		static unsigned long _millis();
		static unsigned long _micros();
		static long _map(long x, long in_min, long in_max, long out_min, long out_max);
		static double _power(double val, int exp);
		static void _noInterrupts();
		static void _interrupts();
		static void _attachInterrupt(uint8_t, void(*)(void), int mode);
		static void _detachInterrupt(uint8_t);
		static uint8_t _digitalPinToInterrupt(uint8_t);
		static uint16_t _makeWord(uint16_t w);
		static uint16_t _makeWord(uint8_t h, uint8_t l);
		static int _freeMemory();

		// Visual special commands
		static void __pinName(int inPin, const char *inName);
	};
}

//-------------------------------------------------------------------
#endif
//-------------------------------------------------------------------
