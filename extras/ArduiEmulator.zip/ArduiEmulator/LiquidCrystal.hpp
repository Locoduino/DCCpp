#ifndef LiquidCrystal_h
#define LiquidCrystal_h

using namespace System;
using namespace System::Collections;

#include "ArduiEmulator.inc"
#include <vcclr.h>

// commands
#define LCD_CLEARDISPLAY 0x01
#define LCD_RETURNHOME 0x02
#define LCD_ENTRYMODESET 0x04
#define LCD_DISPLAYCONTROL 0x08
#define LCD_CURSORSHIFT 0x10
#define LCD_FUNCTIONSET 0x20
#define LCD_SETCGRAMADDR 0x40
#define LCD_SETDDRAMADDR 0x80

// flags for display entry mode
#define LCD_ENTRYRIGHT 0x00
#define LCD_ENTRYLEFT 0x02
#define LCD_ENTRYSHIFTINCREMENT 0x01
#define LCD_ENTRYSHIFTDECREMENT 0x00

// flags for display on/off control
#define LCD_DISPLAYON 0x04
#define LCD_DISPLAYOFF 0x00
#define LCD_CURSORON 0x02
#define LCD_CURSOROFF 0x00
#define LCD_BLINKON 0x01
#define LCD_BLINKOFF 0x00

// flags for display/cursor shift
#define LCD_DISPLAYMOVE 0x08
#define LCD_CURSORMOVE 0x00
#define LCD_MOVERIGHT 0x04
#define LCD_MOVELEFT 0x00

// flags for function set
#define LCD_8BITMODE 0x10
#define LCD_4BITMODE 0x00
#define LCD_2LINE 0x08
#define LCD_1LINE 0x00
#define LCD_5x10DOTS 0x04
#define LCD_5x8DOTS 0x00

public ref class LiquidCrystalManaged
{
private:
	uint8_t posRow, posCol;
	uint8_t nbRows, nbCols;

	bool Display, Blink, Cursor, Autoscroll, ScrollToLeft, LeftToRight;

public:
	LiquidCrystalManaged() 
	{
	}
    
	void begin(uint8_t cols, uint8_t rows)
	{
		this->begin(cols, rows, LCD_5x8DOTS);
	}

	void begin(uint8_t cols, uint8_t rows, uint8_t charsize)
	{
		this->nbRows = rows;
		this->nbCols = cols;
		ArduiEmulator::ArduinoForm::_lcdRows = rows;
		ArduiEmulator::ArduinoForm::_lcdCols = cols;
		this->home();
		this->clear();
	}

	void clear()
	{
		ArduiEmulator::ArduinoForm::_lcdClear();
	}

	void setCursor(uint8_t col, uint8_t row)
	{
		this->posRow = row;
		this->posCol = col;
	}

	void home()
	{
		this->setCursor(0, 0);
	}

	size_t write(uint8_t ch)
	{
		char str[2];
		str[0] = ch;
		str[1] = 0;
		print(gcnew String(str));
		return 1;
	}
		
	void noDisplay() { this->Display = false; ArduiEmulator::ArduinoForm::_lcdnoDisplay(); }
	void display() { this->Display = true; ArduiEmulator::ArduinoForm::_lcddisplay(); }
	void noBlink() { this->Blink = false; ArduiEmulator::ArduinoForm::_lcdnoBlink(); }
	void blink() { this->Blink = true; ArduiEmulator::ArduinoForm::_lcdblink(); }
	void noCursor() { this->Cursor = false; ArduiEmulator::ArduinoForm::_lcdnoCursor(); }
	void cursor() { this->Cursor = true; ArduiEmulator::ArduinoForm::_lcdcursor(); }
	void scrollDisplayLeft() { this->ScrollToLeft = false; ArduiEmulator::ArduinoForm::_lcdscrollDisplayLeft(); }
	void scrollDisplayRight() { this->ScrollToLeft = true; ArduiEmulator::ArduinoForm::_lcdscrollDisplayRight(); }
	void leftToRight() { this->LeftToRight = true; ArduiEmulator::ArduinoForm::_lcdleftToRight(); }
	void rightToLeft() { this->LeftToRight = false; ArduiEmulator::ArduinoForm::_lcdrightToLeft(); }
	void autoscroll() { this->Autoscroll = false; ArduiEmulator::ArduinoForm::_lcdautoscroll(); }
	void noAutoscroll() { this->Autoscroll = true; ArduiEmulator::ArduinoForm::_lcdnoAutoscroll(); }
	void setRowOffsets(int row1, int row2, int row3, int row4) {}
	void createChar(uint8_t, uint8_t[]) {}
	void command(uint8_t) {}

	// Print part

	void print(String^ text)
	{
		ArduiEmulator::ArduinoForm::_lcdPrint(this->posRow, this->posCol, text);
		if (this->posCol < this->nbCols)
			this->posCol += text->Length;
	}

	void print(int value)
	{
		print(value, DEC);
	}

	void print(int value, int i)
	{
		String^ format = gcnew String("{0}");
		switch (i)
		{
		case DEC:
			break;
		case HEX:
			format = gcnew String("{0:X}");
			break;
		case BIN:
			format = gcnew String("{0}");
			break;
		}

		print(String::Format(format, value));
	}
};

class LiquidCrystal
{
private:
	gcroot<LiquidCrystalManaged^> lcd;
	uint8_t _rs, _rw, _enable, _d0, _d1, _d2, _d3, _d4, _d5, _d6, _d7;

public:
	LiquidCrystal(uint8_t rs, uint8_t enable,
		uint8_t d0, uint8_t d1, uint8_t d2, uint8_t d3,
		uint8_t d4, uint8_t d5, uint8_t d6, uint8_t d7) { this->init(0, rs, 0, enable, d0, d1, d2, d3, d4, d5, d6, d7); }
	LiquidCrystal(uint8_t rs, uint8_t rw, uint8_t enable,
		uint8_t d0, uint8_t d1, uint8_t d2, uint8_t d3,
		uint8_t d4, uint8_t d5, uint8_t d6, uint8_t d7) { this->init(0, rs, rw, enable, d0, d1, d2, d3, d4, d5, d6, d7); }
	LiquidCrystal(uint8_t rs, uint8_t rw, uint8_t enable,
		uint8_t d0, uint8_t d1, uint8_t d2, uint8_t d3) { this->init(1, rs, rw, enable, d0, d1, d2, d3, 0, 0, 0, 0); }
	LiquidCrystal(uint8_t rs, uint8_t enable,
		uint8_t d0, uint8_t d1, uint8_t d2, uint8_t d3) { this->init(1, rs, 0, enable, d0, d1, d2, d3, 0, 0, 0, 0); }

	void init(uint8_t fourbitmode, uint8_t rs, uint8_t rw, uint8_t enable,
		uint8_t d0, uint8_t d1, uint8_t d2, uint8_t d3,
		uint8_t d4, uint8_t d5, uint8_t d6, uint8_t d7)
	{
		lcd = gcnew LiquidCrystalManaged(); 
		_rs = rs;
		_rw	= rw;
		_enable	= enable;
		_d0	= d0;
		_d1	= d1;
		_d2	= d2;
		_d3	= d3;
		_d4	= d4;
		_d5	= d5;
		_d6	= d6;
		_d7	= d7;
	}

	void begin(uint8_t cols, uint8_t rows)
	{
		this->begin(cols, rows, LCD_5x8DOTS);
	}

	void begin(uint8_t cols, uint8_t rows, uint8_t charsize)
	{
		lcd->begin(cols, rows, charsize);
		ArduiEmulator::Arduino::_pinMode(_rs, OUTPUT_RESERVED);
		ArduiEmulator::Arduino::_pinMode(_rw, OUTPUT_RESERVED);
		ArduiEmulator::Arduino::_pinMode(_enable, OUTPUT_RESERVED);
		ArduiEmulator::Arduino::_pinMode(_d0, OUTPUT_RESERVED);
		ArduiEmulator::Arduino::_pinMode(_d1, OUTPUT_RESERVED);
		ArduiEmulator::Arduino::_pinMode(_d2, OUTPUT_RESERVED);
		ArduiEmulator::Arduino::_pinMode(_d3, OUTPUT_RESERVED);
		ArduiEmulator::Arduino::_pinMode(_d4, OUTPUT_RESERVED);
		ArduiEmulator::Arduino::_pinMode(_d5, OUTPUT_RESERVED);
		ArduiEmulator::Arduino::_pinMode(_d6, OUTPUT_RESERVED);
		ArduiEmulator::Arduino::_pinMode(_d7, OUTPUT_RESERVED);
	}

	void clear()
	{
		lcd->clear();
	}

	void setCursor(uint8_t col, uint8_t row)
	{
		lcd->setCursor(col, row);
	}

	void home()
	{
		lcd->home();
	}

	size_t write(uint8_t ch)
	{
		return lcd->write(ch);
	}

	void noDisplay() { lcd->noDisplay();	}
	void display() { lcd->display(); }
	void noBlink() { lcd->noBlink(); }
	void blink() { lcd->blink(); }
	void noCursor() { lcd->noCursor(); }
	void cursor() { lcd->cursor(); }
	void scrollDisplayLeft() { lcd->scrollDisplayLeft(); }
	void scrollDisplayRight() { lcd->scrollDisplayRight(); }
	void leftToRight() { lcd->leftToRight(); }
	void rightToLeft() { lcd->rightToLeft(); }
	void autoscroll() { lcd->autoscroll(); }
	void noAutoscroll() { lcd->noAutoscroll(); }

	void setRowOffsets(int row1, int row2, int row3, int row4) {}
	void createChar(uint8_t, uint8_t[]) {}
	void command(uint8_t) {}

	// Print part

	void print(String^ line)
	{
		lcd->print(line);
	}

	void print(const char *line)
	{
		lcd->print(gcnew String(line));
	}

	/*	void println(String^ line)
	{
		lcd->println(line);
	}*/

	void print(int value)
	{
		lcd->print(value);
	}

	void print(int value, int i)
	{
		lcd->print(value, i);
	}

/*	void println(int value)
	{
		lcd->println(value);
	}

	void println(int value, int i)
	{
		lcd->println(value, i);
	}*/
};
#endif
