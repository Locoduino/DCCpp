//-------------------------------------------------------------------
#ifndef __serial_Hpp__
#define __serial_Hpp__
//-------------------------------------------------------------------

using namespace System;
using namespace System::Collections;

public ref class SerialClass
{
public:
	static SerialClass SerialInstance;
	String^ memo;

	void begin(int);
	void end();
	void flush();

	void print(const char *line);
	void println(const char *line);
	void print(String^ line);
	void println(String^ line);
	void print(int value);
	void print(int value, int i);
	void println(int value);
	void println(int value, int i);

	int available();
	char read();
	char peek();
};

//-------------------------------------------------------------------
#endif
//-------------------------------------------------------------------