#include "ArduiEmulator.hpp"

namespace ArduiEmulator
{
	void Arduino::_delay(int millis)
	{
		System::Threading::Thread::Sleep(millis);
	}

	void Arduino::_delayMicroseconds(int micros)
	{
		//System::Threading::Thread::Sleep(millis);
	}

	uint8_t Arduino::_pgm_read_byte(const uint8_t *str)
	{
		_delay(10);
		return (uint8_t)*str;
	}

	int Arduino::_pgm_read_word(const char *str)
	{
		return (int) (__int64)str;
	}

	void Arduino::_pinSetup()
	{
		VC_pins = gcnew array<int>(VCPINNUMBER);
		VC_pinNames = gcnew array<String^>(VCPINNUMBER);
		for (int i = 0; i < VCPINNUMBER; i++)
			VC_pins[i] = -1;
	}

	void Arduino::_pinMode(int inPin, int inType)
	{
		if (inPin <= 0)
			return;

		if (VC_pins[inPin] != -1)
		{
			ArduinoForm::_Error("pin " + inPin.ToString() + " is already declared !");
		}

		switch (inType)
		{
		case INPUT:
			VC_pins[inPin] = VS_LOW;
			break;
		case INPUT_PULLUP:
			VC_pins[inPin] = VS_HIGH;
			break;
		case OUTPUT:
			VC_pins[inPin] = VS_LOW;
			break;
		case OUTPUT_RESERVED:
			VC_pins[inPin] = OUTPUT_RESERVED;
			break;
		case OUTPUT_INTERRUPT:
			VC_pins[inPin] = OUTPUT_INTERRUPT;
			break;
		}
		ArduinoForm::_ShowPins(VC_pins, VC_pinNames);
	}

	void Arduino::_digitalWrite(int inPin, int inValue)
	{
		if (inPin < 0 || inPin >= VCPINNUMBER)
		{
			ArduinoForm::_Error("invalid pin number :" + inPin.ToString());
			return;
		}

		if (VC_pins[inPin] == -1)
			ArduinoForm::_Error("pin " + inPin.ToString() + " is not declared OUTPUT !");

		if (VC_pins[inPin] == OUTPUT_RESERVED)
			ArduinoForm::_Error("pin " + inPin.ToString() + " is already reserved !");

		if (VC_pins[inPin] == OUTPUT_INTERRUPT)
			ArduinoForm::_Error("pin " + inPin.ToString() + " is already used by interruption !");

		if (inValue > 0 != VC_pins[inPin])
		{
			VC_pins[inPin] = inValue > 0 ? VS_HIGH : VS_LOW;
			ArduinoForm::_ShowPins(VC_pins, VC_pinNames);
		}
	}

	int Arduino::_digitalRead(int inPin)
	{
		if (VC_pins[inPin] == OUTPUT_RESERVED)
			ArduinoForm::_Error("pin " + inPin.ToString() + " is reserved !");

		if (VC_pins[inPin] == OUTPUT_INTERRUPT)
			ArduinoForm::_Error("pin " + inPin.ToString() + " is used by interruption !");

		if (VC_pins[inPin] == -1)
		{
			ArduinoForm::_Error("pin " + inPin.ToString() + " is not declared INPUT !");
			VC_pins[inPin] = VS_LOW;
			ArduinoForm::_ShowPins(VC_pins, VC_pinNames);
		}
		return VC_pins[inPin] == VS_LOW ? LOW : HIGH;
	}

	void Arduino::_analogWrite(int inPin, int inValue)
	{
		if (inValue != VC_pins[inPin])
		{
			VC_pins[inPin] = inValue;
			ArduinoForm::_ShowPins(VC_pins, VC_pinNames);
		}
	}

	int Arduino::_analogRead(int inPin)
	{
		if (VC_pins[inPin] == -1)
		{
			VC_pins[inPin] = 0;
			ArduinoForm::_ShowPins(VC_pins, VC_pinNames);
		}
		return VC_pins[inPin];
	}

	unsigned long Arduino::_millis()
	{
		// Get current date and time 
		System::DateTime dateTimeNow = System::DateTime::Now;
		// Calculate the number of milliseconds since midnight
		unsigned long sec = (dateTimeNow.Hour * 3600000) + (dateTimeNow.Minute * 60000) + (dateTimeNow.Second * 1000) + dateTimeNow.Millisecond;
		return sec;
	}

	unsigned long Arduino::_micros()
	{
		return _millis() * 1000;
	}

	long Arduino::_map(long x, long in_min, long in_max, long out_min, long out_max)
	{
		return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
	}

	double Arduino::_power(double val, int exp)
	{
		double res = val;
		for (int i = 0; i < exp; i++)
			res *= val;

		return res;
	}

	void Arduino::_noInterrupts()
	{}

	void Arduino::_interrupts()
	{}

	void Arduino::_attachInterrupt(uint8_t, void(*)(void), int mode)
	{}

	void Arduino::_detachInterrupt(uint8_t)
	{}

	uint8_t Arduino::_digitalPinToInterrupt(uint8_t pin)
	{
		// In Visual Studio mode, just use the pin itself !
		return pin;
	}

	uint16_t Arduino::_makeWord(uint16_t w)
	{
		return w;
	}

	uint16_t Arduino::_makeWord(uint8_t h, uint8_t l)
	{
		return (h << (uint16_t)8) + l;
	}

	int Arduino::_freeMemory()
	{
		// There is always free memory !
		return 20000;
	}

	void Arduino::__pinName(int inPin, const char *inName)
	{
		String^ name = gcnew String(inName);
		VC_pinNames[inPin] = name;
	}
}

