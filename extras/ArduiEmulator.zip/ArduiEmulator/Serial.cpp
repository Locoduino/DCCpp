#include "Arduino.h"
#include "ArduinoForm.hpp"
#include "Serial.hpp"

void SerialClass::begin(int)
{
	ArduiEmulator::ArduinoForm::SerialBuffer = String::Empty;
	this->memo = this->memo->Empty;
}

void SerialClass::end()
{
}

void SerialClass::flush()
{
	ArduiEmulator::ArduinoForm::SerialBuffer = String::Empty;
}

void SerialClass::print(const char *line)
{
	print(gcnew String(line));
}

void SerialClass::println(const char *line)
{
	println(gcnew String(line));
}

void SerialClass::print(String^ line)
{
	this->memo = this->memo + line;
}

void SerialClass::println(String^ line)
{
	ArduiEmulator::ArduinoForm::_debug(this->memo + line);
	this->memo = this->memo->Empty;
}

void SerialClass::print(int value)
{
	print(value, DEC);
}

void SerialClass::print(int value, int i)
{
	switch (i)
	{
	case DEC:
		print(System::Convert::ToString(value, 10));
		break;
	case HEX:
		print(System::Convert::ToString(value, 16));
		break;
	case BIN:
		print(System::Convert::ToString(value, 2)->PadLeft(8, '0'));
		break;
	}
}

void SerialClass::println(int value)
{
	print(value, DEC);
	println(this->memo->Empty);
}

void SerialClass::println(int value, int i)
{
	print(value, i);
	println(this->memo->Empty);
}

int SerialClass::available()
{ 
	return ArduiEmulator::ArduinoForm::SerialBuffer->Length; 
}

char SerialClass::read()
{
	char c = (char) ArduiEmulator::ArduinoForm::SerialBuffer[0];
	ArduiEmulator::ArduinoForm::SerialBuffer = ArduiEmulator::ArduinoForm::SerialBuffer->Remove(0, 1);
	return c;
}

char SerialClass::peek()
{
	return (char) ArduiEmulator::ArduinoForm::SerialBuffer[0];
}
