var searchData=
[
  ['msg',['msg',['../structCurrentMonitor.html#a0d39b1f9324033a87094feebd2b1b501',1,'CurrentMonitor']]]
];
