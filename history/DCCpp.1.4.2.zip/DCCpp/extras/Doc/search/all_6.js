var searchData=
[
  ['get',['get',['../structSensor.html#acf8c90a31492b3f9b76904ef466619f0',1,'Sensor::get()'],['../structTurnout.html#aa4f022fcfeadf52f135b2d0279a8e360',1,'Turnout::get()']]],
  ['getcurrentmain',['getCurrentMain',['../classDCCpp.html#a886cd3d7991f40c558a04642eca5f75f',1,'DCCpp']]],
  ['getcurrentprog',['getCurrentProg',['../classDCCpp.html#a8582f59a9d814ceb10e4381c0905df5b',1,'DCCpp']]]
];
