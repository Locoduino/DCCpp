var searchData=
[
  ['active',['active',['../structSensor.html#ad2dcd5fa3886a4a9c7a5261e1a3ddb51',1,'Sensor']]],
  ['address',['address',['../structTurnoutData.html#a748ccb89448c3efd2b288d779ba231f4',1,'TurnoutData']]]
];
