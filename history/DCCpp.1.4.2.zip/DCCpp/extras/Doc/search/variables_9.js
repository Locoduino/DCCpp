var searchData=
[
  ['sampletime',['sampleTime',['../structCurrentMonitor.html#ad82c5feea9c57d5b8d034d7a69301a81',1,'CurrentMonitor']]],
  ['signal',['signal',['../structSensor.html#a03efc05452821e5fa4990bf6df365dba',1,'Sensor']]],
  ['signalpin',['signalPin',['../structCurrentMonitor.html#aeb5272629eb9b4e810b8f7f21651a6f4',1,'CurrentMonitor']]],
  ['snum',['snum',['../structSensorData.html#a8c649835983803786f3c862a3a213194',1,'SensorData']]],
  ['subaddress',['subAddress',['../structTurnoutData.html#ac5f5d5124dc7595c0717dd793031657a',1,'TurnoutData']]]
];
