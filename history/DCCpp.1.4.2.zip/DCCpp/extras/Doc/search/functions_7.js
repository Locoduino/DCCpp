var searchData=
[
  ['needsrefreshing',['needsRefreshing',['../structEEStore.html#ac1a5510ab808789c2c89b9b62233fd83',1,'EEStore']]]
];
