var searchData=
[
  ['tstatus',['tStatus',['../structTurnoutData.html#abc11a69999b966332b9d6f2314151ad1',1,'TurnoutData']]]
];
