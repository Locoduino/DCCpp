var searchData=
[
  ['getcurrentmain',['getCurrentMain',['../classDCCpp.html#a886cd3d7991f40c558a04642eca5f75f',1,'DCCpp']]],
  ['getcurrentprog',['getCurrentProg',['../classDCCpp.html#a8582f59a9d814ceb10e4381c0905df5b',1,'DCCpp']]]
];
