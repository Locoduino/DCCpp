var searchData=
[
  ['text_20commands_20syntax',['Text Commands Syntax',['../group__commandsGroup.html',1,'']]]
];
