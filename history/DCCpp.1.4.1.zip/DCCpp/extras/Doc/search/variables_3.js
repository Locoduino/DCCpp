var searchData=
[
  ['sampletime',['sampleTime',['../structCurrentMonitor.html#ad82c5feea9c57d5b8d034d7a69301a81',1,'CurrentMonitor']]],
  ['signalpin',['signalPin',['../structCurrentMonitor.html#aeb5272629eb9b4e810b8f7f21651a6f4',1,'CurrentMonitor']]]
];
