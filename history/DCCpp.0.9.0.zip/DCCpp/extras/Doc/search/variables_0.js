var searchData=
[
  ['active',['active',['../structSensor.html#a3acee43f445ecc4630f3ed3419730515',1,'Sensor']]],
  ['address',['address',['../structTurnoutData.html#a45c6bc6d1135dc398bf8deae861a2ebc',1,'TurnoutData']]]
];
