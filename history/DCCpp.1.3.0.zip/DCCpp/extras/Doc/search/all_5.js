var searchData=
[
  ['getcurrentmain',['getCurrentMain',['../classDCCpp.html#a8536b268a9e69b58d17b16970b1ba949',1,'DCCpp']]],
  ['getcurrentprog',['getCurrentProg',['../classDCCpp.html#a9e14e6eb86017ad7b80b7fa14b2a70b0',1,'DCCpp']]]
];
