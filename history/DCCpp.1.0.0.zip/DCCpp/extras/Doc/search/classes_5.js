var searchData=
[
  ['textcommand',['TextCommand',['../structTextCommand.html',1,'']]]
];
