var searchData=
[
  ['tstatus',['tStatus',['../structTurnoutData.html#a78c60dff737057c9d8fb5b4cb3a07a5b',1,'TurnoutData']]]
];
