var searchData=
[
  ['sampletime',['sampleTime',['../structCurrentMonitor.html#ac4ebbe3141ce8efde47e5b55259a6998',1,'CurrentMonitor']]],
  ['signal',['signal',['../structSensor.html#aecd1153495bae55e2b9e8bafc0dac8c1',1,'Sensor']]],
  ['snum',['snum',['../structSensorData.html#a88de83d09c15d47cac7b011ee235b480',1,'SensorData']]],
  ['subaddress',['subAddress',['../structTurnoutData.html#a18cb1e6525ef14974bcbbc2c044f7ab3',1,'TurnoutData']]]
];
