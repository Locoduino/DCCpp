var searchData=
[
  ['needsrefreshing',['needsRefreshing',['../structEEStore.html#a73d53a635e2d8f50cc39d3877d0f8d25',1,'EEStore']]]
];
