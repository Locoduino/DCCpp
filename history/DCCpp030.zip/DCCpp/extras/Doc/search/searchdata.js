var indexSectionsWithContent =
{
  0: "cdfhprtu",
  1: "cdfprt",
  2: "d",
  3: "dp",
  4: "u",
  5: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Macros",
  5: "Pages"
};

